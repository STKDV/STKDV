#pragma once
#ifndef PARALLEL_H
#define PARALLEL_H

#include "kd_Tree.h"
#include "ball_Tree.h"
#include "SWS.h"

void STKDV_parallel(statistics& stat);

#endif