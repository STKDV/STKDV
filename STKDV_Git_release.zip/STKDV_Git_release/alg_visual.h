#pragma once
#ifndef ALG_VISUAL_H
#define ALG_VISUAL_H

#include "init_visual.h"
#include "SS.h"
#include "kd_Tree.h"
#include "ball_Tree.h"
#include "SWS.h"
#include "parallel.h"

void visual_Algorithm(statistics& stat);

#endif