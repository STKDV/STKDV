import React, {useState} from 'react';
import {render} from 'react-dom';

import {StaticMap} from 'react-map-gl';
import DeckGL from '@deck.gl/react';
import {ScatterplotLayer} from '@deck.gl/layers';
import {DataFilterExtension} from '@deck.gl/extensions';
import {MapView} from '@deck.gl/core';
import RangeInput from './range-input';
import {useMemo} from 'react';

// Source data GeoJSON
const DATA_URL =
  'https://raw.githubusercontent.com/uber-web/kepler.gl-data/master/earthquakes/data.csv'; // eslint-disable-line

const MAPBOX_TOKEN = "pk.eyJ1IjoibmljazEyMzQwIiwiYSI6ImNrN2Yzd2J0MjBwejMzZW53YXM1OWljeGoifQ.xiVcY6OOU3Lr8KzrbmQlcg";


// This is only needed for this particular dataset - the default view assumes
// that the furthest geometries are on the ground. Because we are drawing the
// circles at the depth of the earthquakes, i.e. below sea level, we need to
// push the far plane away to avoid clipping them.
const MAP_VIEW = new MapView({
  // 1 is the distance between the camera and the ground
  farZMultiplier: 100
});

const INITIAL_VIEW_STATE = {
  latitude: 36.5,
  longitude: -120,
  zoom: 5.5,
  pitch: 0,
  bearing: 0
};

const MAP_STYLE = 'mapbox://styles/mapbox/light-v9';

const accuracy = 100;

const dataFilter = new DataFilterExtension({
  filterSize: 1,
  // Enable for higher precision, e.g. 1 second granularity
  // See DataFilterExtension documentation for how to pick precision
  fp64: false
});

function formatLabel(t) {
  const date = new Date(t);
  return `${Math.round(t)}`;
}



function getTimeRange(data) {
  if (!data) {
    return null;
  }
  return data.reduce(
    (range, d) => {
      const t = d.timestamp;
      range[0] = Math.min(range[0], t);
      range[1] = Math.max(range[1], t);
      return range;
    },
    [Infinity, -Infinity]
  );
}

function getTimeRange2(data) {
  if (!data) {
    return null;
  }
  return data.reduce(
    (range, d) => {
      const t = d.timestamp;
      range[0] = Math.min(range[0], t);
      range[1] = range[0]
      return range;
    },
    [Infinity, -Infinity]
  );
}
function getTooltip({object}) {
  return (
    object &&
    `\
    Time: ${new Date(object.timestamp).toUTCString()}
    lat: ${object.lat}
    lon: ${object.lon}
    val: ${object.val}
    `
  );
}

export default function App({data, mapStyle = MAP_STYLE}) {

  const [filter, setFilter] = useState(null);

  const timeRange = useMemo(() => getTimeRange(data), [data]);
  const timeRange2 = [5921,7506] //New York
  //const timeRange2 = [7609,7685] //const timeRange2 = [7327,7704] //Hong Kong Full //const timeRange2 = [5921,7506] //New York
  const filterValue = filter || [timeRange2[0],timeRange2[0]];

  function _setFilter(){
    return setFilter(filter);
  }
  const layers = [
    data &&
      new ScatterplotLayer({
        id: 'earthquakes',
        data:'./data/New_York_visual.json',
        opacity: 0.6,
        radiusScale: 10,
        radiusMinPixels: 1,
        wrapLongitude: true,
        filterTransformSize: true,
        filterTransformColor: true,
        getPosition: d => [d.lon, d.lat],
        getRadius: 4,
        getFillColor: d => {
          if (d.val <1){
            return [0,0,0,0]
          }
          const r = (Math.max(d.val, 0));
		  const ratio = 2 * (d.val-0)/1000
          //const ratio = 2 * (d.val-0)/1000 //const ratio = 2 * (d.val-0)/300
          
          return [ 255*(ratio-1),255*(1-ratio),255-255*(ratio-1)-255*(1-ratio),r];
        },

        getFilterValue: d => d.timestamp,
        filterRange: [filterValue[0], filterValue[0]+30],
        extensions: [dataFilter],

        pickable: true
      })
  ];

  return (
    <>
      <DeckGL
        views={MAP_VIEW}
        layers={layers}
        initialViewState={INITIAL_VIEW_STATE}
        controller={true}
        getTooltip = {getTooltip}
      >
        <StaticMap reuseMaps mapStyle={mapStyle} preventStyleDiffing={true} mapboxApiAccessToken = {MAPBOX_TOKEN} />
      </DeckGL>

      {timeRange2 && (
        <RangeInput
          min={timeRange2[0]}
          max={timeRange2[1]}
          value={filterValue}
		  animationSpeed={13/7} //New York
          //animationSpeed={13/40} //animationSpeed={13/12} //Hong Kong Full //animationSpeed={13/7} //New York
          formatLabel={formatLabel}
          onChange={(filter)=> setFilter([filter[0],filter[0]])}
        />
      )}
    </>
  );
}

export function renderToDOM(container) {
  render(<App />, container);
  require('d3-request').csv(DATA_URL, (error, response) => {
    if (!error) {
      const data = response.map(row => ({
        timestamp: new Date(`${row.DateTime} UTC`).getTime(),
        latitude: Number(row.Latitude),
        longitude: Number(row.Longitude),
        depth: Number(row.Depth),
        magnitude: Number(row.Magnitude)
      }));
      render(<App data={data} />, container);
    }
  });
}
