export const chartStyle = {
    bottom: '20px',
    right: '20px',
    width:'40%',
    height:'40%',
    position: 'absolute',
    zIndex: 110,
  };

export const colourStyle = {
  top: '20px',
  right: '20px',
  width:'40%',

  height:'20%',


  position: 'absolute',
  zIndex: 110,
};


export const textStyle = {
  background: '#fff0',
  position: 'absolute',
  fontSize: '12px',
  top:'60px',
  right: '2px',
  zIndex: 130,
};
  