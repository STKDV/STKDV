
import React, { useRef, useEffect } from 'react'
import { chartStyle } from './style';

function hslToRgb(h, s, l){
    var r, g, b;
    if(s == 0){
        r = g = b = l; // achromatic
    }else{
        var hue2rgb = function hue2rgb(p, q, t){
            if(t < 0.0) t += 1.0;
            if(t > 1.0) t -= 1.0;
            if(t < 1.0/6.0) return p + (q - p) * 6.0 * t;
            if(t < 1.0/2.0) return q;
            if(t < 2.0/3.0) return p + (q - p) * (2.0/3.0 - t) * 6.0;
            return p;
        }
  
        var q = l < 0.5 ? l * (1.0 + s) : l + s - l * s;
        var p = 2.0 * l - q;
        r = hue2rgb(p, q, h + 1.0/3.0);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1.0/3.0);
    }
    r = Math.min(Math.floor(r*256),255)
    g = Math.min(Math.floor(g*256),255)
    b = Math.min(Math.floor(b*256),255)

    return '#'+ r.toString(16).padStart(2,0)+g.toString(16).padStart(2,0)+b.toString(16).padStart(2,0)

  }

const Canvas = props => {
  const shift = 200
  const canvasRef = useRef(null)
  const draw = ctx => {
    var grd = ctx.createLinearGradient(0, 0, props.width-shift, 0);
    ctx.lineWidth=0.5;
    const colour_range = 50
    ctx.font = "24px '微软雅黑'";
    for(var i=0;i<colour_range;i++){
        var h = (1.0 - Math.min(1,Math.max(0,(i/colour_range))))*2.0/3.0
        grd.addColorStop((i)/colour_range, hslToRgb(h,1,0.5));
    }
    ctx.fillStyle = grd;
    ctx.fillRect(10, 0, props.width-shift-10, 30);

    ctx.lineWidth=0.5

    ctx.beginPath()
    ctx.moveTo(10,50-10)
    ctx.lineTo(props.width-shift, 50-10)   
    ctx.closePath()
    ctx.stroke()
    ctx.fillStyle='#000000'
    
    
    ctx.fillRect((props.width-shift)/5*0+10, 50-15, 5, 5);
    ctx.fillText(props.maxValue/5*0,5,60)
    
    for(var i=1;i<5;i++){
      ctx.fillRect((props.width-shift)/5*i, 50-15, 5, 5);
      ctx.fillText(props.maxValue/5*i,(props.width-shift)/5*i-5*(i>0),60)
    }
    ctx.fillRect(props.width-5-shift, 50-15, 5, 5);
    ctx.fillText(props.maxValue,props.width-55-shift+40,60)


}
  
  useEffect(() => {
    
    const canvas = canvasRef.current
    const context = canvas.getContext('2d')
    draw(context)
  }, [draw])
  
  
  return (
      <>
  <canvas ref={canvasRef} {...props}/>
  </>
  )
}


export default React.memo(Canvas)