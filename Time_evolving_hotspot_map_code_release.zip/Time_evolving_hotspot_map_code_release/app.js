import React, {useState} from 'react';
import {render} from 'react-dom';

import {StaticMap} from 'react-map-gl';
import DeckGL from '@deck.gl/react';
import {ScatterplotLayer} from '@deck.gl/layers';
import {DataFilterExtension} from '@deck.gl/extensions';
import {MapView} from '@deck.gl/core';
import RangeInput from './range-input';
import {useMemo} from 'react';
import {textStyle,chartStyle,colourStyle} from './style'
import Canvas from './canvas'


// Source data GeoJSON
const DATA_URL =
  'https://raw.githubusercontent.com/uber-web/kepler.gl-data/master/earthquakes/data.csv'; // eslint-disable-line

const MAPBOX_TOKEN = "pk.eyJ1IjoibmljazEyMzQwIiwiYSI6ImNrN2Yzd2J0MjBwejMzZW53YXM1OWljeGoifQ.xiVcY6OOU3Lr8KzrbmQlcg";


// This is only needed for this particular dataset - the default view assumes
// that the furthest geometries are on the ground. Because we are drawing the
// circles at the depth of the earthquakes, i.e. below sea level, we need to
// push the far plane away to avoid clipping them.
const MAP_VIEW = new MapView({
  // 1 is the distance between the camera and the ground
  farZMultiplier: 100
});

const INITIAL_VIEW_STATE = {
  latitude: 40.8,
  longitude: -73.253,

  zoom: 12,
  pitch: 0,
  bearing: 0
};


const MAP_STYLE = 'mapbox://styles/mapbox/light-v9';

const accuracy = 100;

const dataFilter = new DataFilterExtension({
  filterSize: 1,
  // Enable for higher precision, e.g. 1 second granularity
  // See DataFilterExtension documentation for how to pick precision
  fp64: false
});

function formatLabel(t) {
  const date = new Date(t);
  return `${Math.round(t)}`;
}



function getTimeRange(data) {
  if (!data) {
    return null;
  }
  return data.reduce(
    (range, d) => {
      const t = d.timestamp;
      range[0] = Math.min(range[0], t);
      range[1] = Math.max(range[1], t);
      return range;
    },
    [Infinity, -Infinity]
  );
}
function hslToRgb(h, s, l){
  var r, g, b;
  if(s == 0){
      r = g = b = l; // achromatic
  }else{
      var hue2rgb = function hue2rgb(p, q, t){
          if(t < 0.0) t += 1.0;
          if(t > 1.0) t -= 1.0;
          if(t < 1.0/6.0) return p + (q - p) * 6.0 * t;
          if(t < 1.0/2.0) return q;
          if(t < 2.0/3.0) return p + (q - p) * (2.0/3.0 - t) * 6.0;
          return p;
      }

      var q = l < 0.5 ? l * (1.0 + s) : l + s - l * s;
      var p = 2.0 * l - q;
      r = hue2rgb(p, q, h + 1.0/3.0);
      g = hue2rgb(p, q, h);
      b = hue2rgb(p, q, h - 1.0/3.0);
  }
  r = Math.min(Math.floor(r*256),255)
  g = Math.min(Math.floor(g*256),255)
  b = Math.min(Math.floor(b*256),255)
  return [r,g,b];
}
function getTimeRange2(data) {
  if (!data) {
    return null;
  }
  return data.reduce(
    (range, d) => {
      const t = d.timestamp;
      range[0] = Math.min(range[0], t);
      range[1] = range[0]
      return range;
    },
    [Infinity, -Infinity]
  );
}
function getTooltip({object}) {
  return (
    object &&
    `\
    Time: ${new Date(object.timestamp).toUTCString()}
    lat: ${object.lat}
    lon: ${object.lon}
    val: ${object.val}
    `
  );
}

export default function App({data, mapStyle = MAP_STYLE}) {

  const [filter, setFilter] = useState(null);

  const timeRange = useMemo(() => getTimeRange(data), [data]);
  const timeRange2 = [5921,7506] //New York
  const filterValue = filter || [timeRange2[0],timeRange2[0]];
  const maxValue = 10 //Normalization
  
  //const maxValue = 100
  function _setFilter(){
    return setFilter(filter);
  }
  const layers = [
    data &&
      new ScatterplotLayer({
        id: 'earthquakes',
		data:'./data/Upper_Manhattan_NY_traffic_accident_hotspot.json',
		
        opacity: 0.6,
        radiusScale: 10,
        radiusMinPixels: 1,
        wrapLongitude: true,
        filterTransformSize: true,
        filterTransformColor: true,
        getPosition: d => [d.lon, d.lat],
        getRadius: 4,
        getFillColor: d => {
          if (d.val <1){
            return [0,0,0,0]
          }
          const r = (Math.max(d.val, 0));

        const h = (1.0 - Math.min(1,Math.max(0,(d.val/maxValue))))*2.0/3.0
        var a = 1
        if (d.val < 100){
          a = d.val/100.0
        }
        return hslToRgb(h,1,0.5,a)
      },
        getFilterValue: d => d.timestamp,
        filterRange: [filterValue[0], filterValue[0]+30],
        extensions: [dataFilter],

        pickable: true
      })
  ];

  return (
    <>
      <div style = {colourStyle}>
        <Canvas maxValue={maxValue} width={window.innerWidth*0.5} height={80}>
        </Canvas>
      </div>

      <DeckGL
        views={MAP_VIEW}
        layers={layers}
        initialViewState={INITIAL_VIEW_STATE}
        controller={true}
        getTooltip = {getTooltip}
      >
        <StaticMap reuseMaps mapStyle={mapStyle} preventStyleDiffing={true} mapboxApiAccessToken = {MAPBOX_TOKEN} />
      </DeckGL>

      {timeRange2 && (
        <RangeInput
          min={timeRange2[0]}
          max={timeRange2[1]}
          value={filterValue}
		  animationSpeed={13/7}
          formatLabel={formatLabel}
          onChange={(filter)=> setFilter([filter[0],filter[0]])}
        />
      )}
    </>
  );
}

export function renderToDOM(container) {
  render(<App />, container);
  require('d3-request').csv(DATA_URL, (error, response) => {
    if (!error) {
      const data = response.map(row => ({
        timestamp: new Date(`${row.DateTime} UTC`).getTime(),
        latitude: Number(row.Latitude),
        longitude: Number(row.Longitude),
        depth: Number(row.Depth),
        magnitude: Number(row.Magnitude)
      }));
      render(<App data={data} />, container);
    }
  });
}
